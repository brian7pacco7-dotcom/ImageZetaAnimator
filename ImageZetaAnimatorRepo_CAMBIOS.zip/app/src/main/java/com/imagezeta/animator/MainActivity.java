package com.imagezeta.animator;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int PICK_IMAGE = 1001;

    private EditorCanvasView editorView;

    private LinearLayout leftPanel;
    private Button btnTogglePanel;
    private boolean panelVisible = true;
    private int panelWidth;

    private Button btnUndo;
    private Button btnRedo;

    private Button btnOpen;
    private Button btnEraser;
    private Button btnWand;
    private Button btnArea;
    private Button btnEraseArea;
    private Button btnBg;
    private Button btnReset;
    private Button btnSave;

    private TextView txtSize;
    private TextView txtTolerance;
    private TextView txtSoftness;
    private TextView txtBgMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLayout();
    }

    private void buildLayout() {
        panelWidth = dp(118);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(45, 45, 45));

        editorView = new EditorCanvasView(this);
        root.addView(editorView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        LinearLayout topActions = new LinearLayout(this);
        topActions.setOrientation(LinearLayout.HORIZONTAL);
        topActions.setGravity(Gravity.CENTER);
        topActions.setPadding(dp(6), dp(6), dp(6), dp(6));

        btnUndo = roundButton("↶");
        btnRedo = roundButton("↷");

        topActions.addView(btnUndo);
        topActions.addView(btnRedo);

        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        topParams.gravity = Gravity.TOP | Gravity.LEFT;
        topParams.leftMargin = dp(8);
        topParams.topMargin = dp(8);
        root.addView(topActions, topParams);

        leftPanel = new LinearLayout(this);
        leftPanel.setOrientation(LinearLayout.VERTICAL);
        leftPanel.setGravity(Gravity.CENTER_HORIZONTAL);
        leftPanel.setPadding(dp(6), dp(8), dp(6), dp(8));
        leftPanel.setBackgroundColor(Color.rgb(18, 18, 18));

        btnOpen = panelButton("ABRIR");
        btnEraser = panelButton("BORRADOR\nOFF");
        btnWand = panelButton("VARITA\nOFF");
        btnArea = panelButton("ÁREA\nOFF");
        btnEraseArea = panelButton("BORRAR\nÁREA");
        btnBg = panelButton("FONDO");
        btnReset = panelButton("RESTAURAR");
        btnSave = panelButton("GUARDAR");

        TextView titleTools = label("HERRAM.");
        TextView titleConfig = label("CONFIG");

        txtSize = label("Tamaño\n45");
        txtTolerance = label("Tolerancia\n80");
        txtSoftness = label("Suavidad\n8");
        txtBgMode = label("Fondo\nTablero");

        SeekBar seekSize = new SeekBar(this);
        seekSize.setMax(190);
        seekSize.setProgress(35);

        SeekBar seekTolerance = new SeekBar(this);
        seekTolerance.setMax(255);
        seekTolerance.setProgress(80);

        SeekBar seekSoftness = new SeekBar(this);
        seekSoftness.setMax(50);
        seekSoftness.setProgress(8);

        addPanelView(titleTools);
        addPanelView(btnOpen);
        addPanelView(btnEraser);
        addPanelView(btnWand);
        addPanelView(btnArea);
        addPanelView(btnEraseArea);
        addPanelView(btnBg);
        addPanelView(btnReset);
        addPanelView(btnSave);

        addPanelView(titleConfig);
        addPanelView(txtSize);
        addPanelView(seekSize);
        addPanelView(txtTolerance);
        addPanelView(seekTolerance);
        addPanelView(txtSoftness);
        addPanelView(seekSoftness);
        addPanelView(txtBgMode);

        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
                panelWidth,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        panelParams.gravity = Gravity.LEFT;
        panelParams.topMargin = dp(72);
        root.addView(leftPanel, panelParams);

        btnTogglePanel = new Button(this);
        btnTogglePanel.setText("◀");
        btnTogglePanel.setTextSize(16f);
        btnTogglePanel.setTextColor(Color.WHITE);
        btnTogglePanel.setAllCaps(false);
        btnTogglePanel.setBackgroundColor(Color.rgb(40, 40, 40));

        FrameLayout.LayoutParams toggleParams = new FrameLayout.LayoutParams(
                dp(28),
                dp(84)
        );
        toggleParams.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
        toggleParams.leftMargin = panelWidth;
        root.addView(btnTogglePanel, toggleParams);

        setContentView(root);

        editorView.setBrushSize(45);
        editorView.setMagicTolerance(80);
        editorView.setEdgeSoftness(8);

        btnTogglePanel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                panelVisible = !panelVisible;
                updatePanelVisibility();
            }
        });

        btnUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.undo();
            }
        });

        btnRedo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.redo();
            }
        });

        seekSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = 10 + progress;
                editorView.setBrushSize(value);
                txtSize.setText("Tamaño\n" + value);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekTolerance.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress;
                editorView.setMagicTolerance(value);
                txtTolerance.setText("Tolerancia\n" + value);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekSoftness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                editorView.setEdgeSoftness(progress);
                txtSoftness.setText("Suavidad\n" + progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openImage();
            }
        });

        btnEraser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.toggleEraser();

                if (editorView.isEraserEnabled()) {
                    editorView.setWandEnabled(false);
                    editorView.setLassoEnabled(false);

                    btnEraser.setText("BORRADOR\nON");
                    btnWand.setText("VARITA\nOFF");
                    btnArea.setText("ÁREA\nOFF");
                    Toast.makeText(MainActivity.this, "Borrador activado", Toast.LENGTH_SHORT).show();
                } else {
                    btnEraser.setText("BORRADOR\nOFF");
                }
            }
        });

        btnWand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.toggleWand();

                if (editorView.isWandEnabled()) {
                    editorView.setEraserEnabled(false);
                    editorView.setLassoEnabled(false);

                    btnWand.setText("VARITA\nON");
                    btnEraser.setText("BORRADOR\nOFF");
                    btnArea.setText("ÁREA\nOFF");
                    Toast.makeText(MainActivity.this, "Varita activada", Toast.LENGTH_SHORT).show();
                } else {
                    btnWand.setText("VARITA\nOFF");
                }
            }
        });

        btnArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.toggleLasso();

                if (editorView.isLassoEnabled()) {
                    editorView.setEraserEnabled(false);
                    editorView.setWandEnabled(false);

                    btnArea.setText("ÁREA\nON");
                    btnEraser.setText("BORRADOR\nOFF");
                    btnWand.setText("VARITA\nOFF");
                    Toast.makeText(MainActivity.this, "Dibuja el área", Toast.LENGTH_SHORT).show();
                } else {
                    btnArea.setText("ÁREA\nOFF");
                }
            }
        });

        btnEraseArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean ok = editorView.applyLassoErase();

                if (ok) {
                    Toast.makeText(MainActivity.this, "Área borrada", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Primero dibuja un área", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mode = editorView.cycleBackgroundMode();
                txtBgMode.setText("Fondo\n" + mode);
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editorView.resetImage();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveImage();
            }
        });
    }

    private void updatePanelVisibility() {
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) btnTogglePanel.getLayoutParams();

        if (panelVisible) {
            leftPanel.setVisibility(View.VISIBLE);
            params.leftMargin = panelWidth;
            btnTogglePanel.setText("◀");
        } else {
            leftPanel.setVisibility(View.GONE);
            params.leftMargin = 0;
            btnTogglePanel.setText("▶");
        }

        btnTogglePanel.setLayoutParams(params);
    }

    private Button panelButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11f);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(35, 35, 35));
        bg.setStroke(dp(1), Color.rgb(78, 78, 78));
        bg.setCornerRadius(dp(5));
        b.setBackground(bg);

        return b;
    }

    private Button roundButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18f);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(45, 45, 45));
        bg.setStroke(dp(1), Color.rgb(90, 90, 90));
        b.setBackground(bg);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(42), dp(42));
        params.setMargins(dp(3), dp(2), dp(3), dp(2));
        b.setLayoutParams(params);

        return b;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(11f);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void addPanelView(View view) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dp(3), 0, dp(3));
        leftPanel.addView(view, params);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void openImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();

                if (uri == null) {
                    Toast.makeText(this, "Imagen no válida", Toast.LENGTH_SHORT).show();
                    return;
                }

                Bitmap bitmap = decodeBitmapFromUri(uri, 2400);

                if (bitmap == null) {
                    Toast.makeText(this, "No se pudo abrir imagen", Toast.LENGTH_SHORT).show();
                    return;
                }

                editorView.setBitmap(bitmap);
                Toast.makeText(this, "Imagen cargada", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                Toast.makeText(this, "Error al abrir", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private Bitmap decodeBitmapFromUri(Uri uri, int maxSize) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;

            InputStream input1 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(input1, null, bounds);
            if (input1 != null) input1.close();

            int sample = 1;
            while ((bounds.outWidth / sample) > maxSize || (bounds.outHeight / sample) > maxSize) {
                sample *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;

            InputStream input2 = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(input2, null, options);
            if (input2 != null) input2.close();

            return bitmap;

        } catch (Exception e) {
            return null;
        }
    }

    private void saveImage() {
        try {
            Bitmap bitmap = editorView.getEditedBitmap();

            if (bitmap == null) {
                Toast.makeText(this, "Primero abre una imagen", Toast.LENGTH_SHORT).show();
                return;
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "ImageZeta_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ImageZeta");

            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

            if (uri == null) {
                Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_SHORT).show();
                return;
            }

            OutputStream outputStream = getContentResolver().openOutputStream(uri);

            if (outputStream == null) {
                Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_SHORT).show();
                return;
            }

            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();

            Toast.makeText(this, "Guardado en Imágenes/ImageZeta", Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar", Toast.LENGTH_SHORT).show();
        }
    }
}
