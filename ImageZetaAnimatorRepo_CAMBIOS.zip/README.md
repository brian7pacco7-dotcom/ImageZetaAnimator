# Image Zeta Animator

Editor Android para recortar fondos con borrador, varita mágica y selección libre.

## Versión corregida
- Flechas de deshacer/rehacer separadas arriba.
- Panel izquierdo compacto con flecha separada para ocultar/mostrar.
- Sin barra inferior.
- Fondo tablero/blanco/negro solo dentro del área de la imagen.
- Borrador con tamaño y suavidad.
- Varita mágica mejorada con tolerancia 0-255 y suavidad profunda.
- Área libre con línea blanca simple.
- Zoom y giro con dos dedos.
- Guardado PNG.
