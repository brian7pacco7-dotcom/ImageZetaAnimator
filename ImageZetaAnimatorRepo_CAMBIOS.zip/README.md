# Image Zeta Animator

Editor Android simple para recortar fondos con borrador, varita mágica y selección libre.

## Cambios incluidos
- Panel izquierdo compacto con herramientas y configuración.
- Flecha separada para ocultar/mostrar el panel izquierdo.
- Sin barra inferior.
- Fondo tablero/blanco/negro solo dentro de la imagen.
- Borrador mejorado con tamaño y suavidad.
- Varita mágica por color con tolerancia 0-255.
- Área libre con línea blanca simple.
- Zoom y giro con dos dedos.
- Deshacer y rehacer.
