# Image Zeta Animator

Proyecto Android listo para subir a GitHub y generar APK con GitHub Actions.

## Cómo usar

1. Sube esta carpeta completa a un repositorio nuevo en GitHub.
2. Entra a **Actions**.
3. Ejecuta **Generate APK**.
4. Descarga el artefacto **ImageZetaAnimator-APK**.
5. Instala `app-debug.apk` en Android.

## Funciones

- Abrir imagen.
- Borrador tipo pincel con tamaño y suavidad.
- Varita mágica por color con tolerancia hasta 255.
- Selección libre tipo área con línea blanca simple.
- Borrar solo el área seleccionada.
- Fondo tipo tablero, blanco o negro.
- Zoom, mover y girar con dos dedos.
- Deshacer y rehacer.
- Panel izquierdo compacto con flecha para ocultar/mostrar.
